﻿namespace deweydecimal
{
    partial class tests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.QUESTIONS = new System.Windows.Forms.ListBox();
            this.ANSWERS = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // QUESTIONS
            // 
            this.QUESTIONS.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.QUESTIONS.FormattingEnabled = true;
            this.QUESTIONS.ItemHeight = 20;
            this.QUESTIONS.Items.AddRange(new object[] {
            "A 000-099 ",
            "B 100-199",
            "C 200-299 ",
            "D 300-399",
            "E 400-499",
            "F 500-599",
            "G 600-699 ",
            "H 700-799",
            "I 800-899",
            "J 900-999",
            "K 92A-92Z"});
            this.QUESTIONS.Location = new System.Drawing.Point(33, 25);
            this.QUESTIONS.Name = "QUESTIONS";
            this.QUESTIONS.Size = new System.Drawing.Size(138, 204);
            this.QUESTIONS.TabIndex = 0;
            // 
            // ANSWERS
            // 
            this.ANSWERS.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ANSWERS.FormattingEnabled = true;
            this.ANSWERS.ItemHeight = 20;
            this.ANSWERS.Items.AddRange(new object[] {
            "1 Technology(Applied Sciences)",
            "2 Social Sciences",
            "3 Natural Sciences & Mathematics",
            "4 Literature & Rhetoric",
            "5 Biography: Biographies",
            "6 History & Geography",
            "7 Computer Science",
            "8 Arts & Recreation",
            "9 Philosophy & Psychology",
            "10 Language: Languages & Dictionaries"});
            this.ANSWERS.Location = new System.Drawing.Point(177, 25);
            this.ANSWERS.Name = "ANSWERS";
            this.ANSWERS.Size = new System.Drawing.Size(259, 204);
            this.ANSWERS.TabIndex = 1;
            this.ANSWERS.SelectedIndexChanged += new System.EventHandler(this.ANSWERS_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.progressBar);
            this.groupBox1.Controls.Add(this.ANSWERS);
            this.groupBox1.Controls.Add(this.QUESTIONS);
            this.groupBox1.Location = new System.Drawing.Point(21, 233);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(852, 266);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MATCH THE COLUMNS";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.textBox1.Location = new System.Drawing.Point(451, 25);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(250, 204);
            this.textBox1.TabIndex = 3;
            // 
            // progressBar
            // 
            this.progressBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.progressBar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.progressBar.Location = new System.Drawing.Point(70, 236);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(214, 23);
            this.progressBar.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(770, 505);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "RESULTS";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Items.AddRange(new object[] {
            "PLEASE MATCH COLUMNS A -B TO ANSWERS HERES A E.G A)7"});
            this.listBox1.Location = new System.Drawing.Point(432, 215);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(441, 24);
            this.listBox1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.Location = new System.Drawing.Point(584, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(232, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "YOU HAVE 100 POINTS KEEP IT UP";
            // 
            // tests
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(945, 672);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "tests";
            this.Text = "tests";
            this.Load += new System.EventHandler(this.tests_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox QUESTIONS;
        private System.Windows.Forms.ListBox ANSWERS;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
    }
}