﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace deweydecimal
{
    public partial class RESULT : Form
    {
        public RESULT()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            menu Frm2 = new menu();
            Frm2.Show();
        }
    }
}
