﻿namespace deweydecimal
{
    internal class quiz
    {
    }
}