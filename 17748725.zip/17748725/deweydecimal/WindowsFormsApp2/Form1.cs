﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;
        
        public Form1()
        {
         
            InitializeComponent();
        askQuestion(questionNumber);
        totalQuestions = 6;
        }

    private void label1_Click(object sender, EventArgs e)
    {

    }



    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void checkAnswerEvent(object sender, EventArgs e)
    {
        var senderObject = (Button)sender;
        int buttonTag = Convert.ToInt32(senderObject.Tag);
        if (buttonTag == correctAnswer)
        {
            questionNumber++;
            askQuestion(questionNumber);
        }

    }
    private void askQuestion(int qnum)
    {
        switch (qnum)
        {
            case 1;
                pictureBox1.Image = Properties.Resources.questions;
                LBLQUESTION.Text = "choose the correct classifcation-Class 401 Philosophy & theory; international languages ?";
                button1.Text = "Language";
                button2.Text = "Yellow";
                button3.Text = "Qrange";
                button4.Text = "Red";

                correctAnswer = 1;

                break;

            case 2;
                pictureBox1.Image = Properties.Resources.questions;
                LBLQUESTION.Text = "choose the correct classifcation-604 Technical drawing, hazardous materials technology; groups of people ";
                button1.Text = "blue";
                button2.Text = "Technology";
                button3.Text = "Qrange";
                button4.Text = "Red";

                correctAnswer = 2;

                break;

            case 3;
                pictureBox1.Image = Properties.Resources.questions;
                LBLQUESTION.Text = "choose the correct classifcation-Class 800 Literature (Belles-lettres) & rhetoric ";
                button1.Text = "blue";
                button2.Text = "Yellow";
                button3.Text = "Literature";
                button4.Text = "Red";

                correctAnswer = 3;

                break;
            case 4;
                pictureBox1.Image = Properties.Resources.questions;
                LBLQUESTION.Text = "choose the correct classifcation-Class 701 Philosophy & theory of fine & decorative arts ";
                button1.Text = "blue";
                button2.Text = "Yellow";
                button3.Text = "orange";
                button4.Text = "Arts & recreation";

                correctAnswer = 4;
                break;

            case 5;
                pictureBox1.Image = Properties.Resources.questions;
                LBLQUESTION.Text = "choose the correct classifcation-Class 201 Religious mythology, general classes of religion, interreligious relations and attitudes, social theology";
                button1.Text = "blue";
                button2.Text = " Religion";
                button3.Text = "orange";
                button4.Text = "black";
                correctAnswer = 2;
                break;

            case 6;
                pictureBox1.Image = Properties.Resources.questions;
                LBLQUESTION.Text = "choose the correct classifcation-004 Data processing & computer science  ";
                button1.Text = "blue";
                button2.Text = "green";
                button3.Text = "Computer science, knowledge & systems";
                button4.Text = "black";
                correctAnswer = 3;
                break;

        }
    }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }
    } }
